<?php
require ../../library.php
?>